import os
import pandas as pd
import upstox_client
from datetime import datetime, timedelta
from dotenv import load_dotenv
import logging
import time

load_dotenv()
logger = logging.getLogger(__name__)

class HistoricalDownloader:
    def __init__(self, api_key, access_token):
        self.configuration = upstox_client.Configuration()
        self.configuration.access_token = access_token
        self.api_instance = upstox_client.HistoryApi(upstox_client.ApiClient(self.configuration))

    def fetch_data(self, instrument_key, interval='1minute', days=30):
        """
        Fetches historical data for a given instrument in chunks if necessary.
        """
        all_candles = []
        end_date = datetime.now()
        
        # Upstox often limits 1min data to ~30-100 days per request. 
        # We'll fetch in 30-day chunks for safety.
        remaining_days = days
        current_end = end_date

        while remaining_days > 0:
            chunk_days = min(remaining_days, 30)
            current_from = current_end - timedelta(days=chunk_days)
            
            logger.info(f"Fetching chunk: {current_from.date()} to {current_end.date()}")
            
            try:
                api_response = self.api_instance.get_historical_candle_data1(
                    instrument_key, interval, 
                    current_end.strftime('%Y-%m-%d'), 
                    current_from.strftime('%Y-%m-%d'), 
                    '2.0'
                )
                
                if api_response.status == 'success':
                    all_candles.extend(api_response.data.candles)
                else:
                    logger.error(f"Failed to fetch chunk: {api_response.errors}")
                    break
                    
            except Exception as e:
                logger.error(f"Exception during chunk fetch: {e}")
                break
            
            # Update for next chunk
            current_end = current_from - timedelta(days=1)
            remaining_days -= chunk_days
            time.sleep(1) # Rate limiting safety

        if not all_candles:
            return None

        df = pd.DataFrame(all_candles, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume', 'oi'])
        df['timestamp'] = pd.to_datetime(df['timestamp'])
        df = df.sort_values('timestamp').reset_index(drop=True)
        return df

    def save_to_csv(self, df, filename):
        if df is None:
            logger.error("No data to save.")
            return
        os.makedirs('historical', exist_ok=True)
        path = os.path.join('historical', filename)
        df.to_csv(path, index=False)
        logger.info(f"Saved {len(df)} candles to {path}")

if __name__ == "__main__":
    API_KEY = os.getenv("UPSTOX_API_KEY")
    ACCESS_TOKEN = os.getenv("UPSTOX_ACCESS_TOKEN")
    
    if API_KEY and ACCESS_TOKEN:
        downloader = HistoricalDownloader(API_KEY, ACCESS_TOKEN)
        # Fetch 120 days
        df = downloader.fetch_data("NSE_INDEX|Nifty 50", days=120)
        downloader.save_to_csv(df, "nifty_50_120d.csv")
    else:
        print("Credentials missing in .env")
